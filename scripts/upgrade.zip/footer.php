<?php
  /**
   * Footer
   *
   * @package Membership Manager Pro
   * @author wojoscripts.com
   * @copyright 2010
   * @version $Id: footer.php, v2.00 2011-07-10 10:12:05 gewa Exp $
   */
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<!-- Start Footer-->
<footer id="footer" class="clearfix">
  Copyright &copy;<?php echo date('Y').' '.$core->site_name;?><br />
    Wojoscripts.com &bull; Membership Manager Pro v<?php echo $core->version;?>
</footer>
<!-- End Footer-->
</div><!-- container /-->
</body></html>
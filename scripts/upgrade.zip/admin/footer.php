<?php
  /**
   * Footer
   *
   * @package Membership Manager Pro
   * @author wojoscripts.com
   * @copyright 2010
   * @version $Id: footer.php, v2.00 2011-07-10 10:12:05 gewa Exp $
   */
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
</div>
<div class="top20">&nbsp;</div>
<!-- Start Footer-->
<div class="footer">
  Copyright &copy;<?php echo date('Y').' '.$core->site_name;?><br />
    Wojoscripts.com &bull; Membership Manager Pro v<?php echo $core->version;?>
</div>
<!-- End Footer-->
<!-- The Main Menu Js -->
<script type="text/javascript">
var menu = new cbpHorizontalSlideOutMenu(document.getElementById('cbp-hsmenu-wrapper'));
</script>
<!-- The Main Menu Js /-->
</body></html>